# MathProofBenchmark — Lean 4 / Mathlib


A small reproducible benchmark of mathematical statements with reference proofs. It demonstrates how mathematical claims can be represented in Lean and checked by the compiler.


## Included benchmark problems
- Natural-number addition commutativity and associativity
- Natural-number multiplication commutativity
- Integer square non-negativity
- List length properties for `map`, `reverse`, and `append`

## Setup
Install Lean 4 using `elan`, then from this directory run:

```bash
lake update
lake build
```

A successful build means the included reference proofs are accepted by Lean/Mathlib.

## Adding a problem
1. Add a theorem statement to `MathProofBenchmark/Basic.lean`.
2. Write a reference proof.
3. Run `lake build` to validate it.
4. Keep each benchmark small and self-contained so it can be reviewed or reused.

## Scope
This is a starter benchmark, not a large benchmark dataset. It uses compilation as a proof-validity check and does not claim to measure proof quality, model performance, or difficulty statistically.
