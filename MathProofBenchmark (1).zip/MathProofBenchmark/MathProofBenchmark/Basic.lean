import Mathlib

/-!
# Math Proof Benchmark
A small starter benchmark of statements with machine-checkable reference proofs.
- Each problem has a theorem statement and a reference proof.
- A Lean build checks proof validity; a successful build is the correctness signal.
- Extend the suite with new statements and candidate proofs.
-/

namespace MathProofBenchmark


-- Category: arithmetic
 theorem addition_comm_benchmark (a b : Nat) : a + b = b + a := by
  exact Nat.add_comm a b

 theorem addition_associative_benchmark (a b c : Nat) : (a + b) + c = a + (b + c) := by
  exact Nat.add_assoc a b c
 theorem multiplication_comm_benchmark (a b : Nat) : a * b = b * a := by
  exact Nat.mul_comm a b
 theorem square_nonnegative_benchmark (a : Int) : 0 ≤ a * a := by
  nlinarith

-- Category: list reasoning
 theorem map_preserves_length_benchmark (f : Nat → Nat) (xs : List Nat) :
    (xs.map f).length = xs.length := by
  simp
 theorem reverse_preserves_length_benchmark (xs : List Nat) :
    xs.reverse.length = xs.length := by
  simp
 theorem append_length_benchmark (xs ys : List Nat) :
    (xs ++ ys).length = xs.length + ys.length := by
  simp

end MathProofBenchmark
